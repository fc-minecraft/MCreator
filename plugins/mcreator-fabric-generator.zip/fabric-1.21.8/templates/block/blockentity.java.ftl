<#--
 # This file is part of Fabric-Generator-MCreator.
 # Copyright (C) 2012-2020, Pylo
 # Copyright (C) 2020-2025, Pylo, opensource contributors
 # Copyright (C) 2020-2025, Goldorion, opensource contributors
 #
 # Fabric-Generator-MCreator is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, either version 3 of the License, or
 # (at your option) any later version.
 #
 # Fabric-Generator-MCreator is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with Fabric-Generator-MCreator. If not, see <https://www.gnu.org/licenses/>.
-->

<#-- @formatter:off -->
<#include "../procedures.java.ftl">
package ${package}.block.entity;

<#compress>
public class ${name}BlockEntity extends RandomizableContainerBlockEntity implements WorldlyContainer
		<#if data.sensitiveToVibration>, GameEventListener.Provider<VibrationSystem.Listener>, VibrationSystem</#if> {

	private NonNullList<ItemStack> stacks = NonNullList.withSize(${data.inventorySize}, ItemStack.EMPTY);

	<#if data.sensitiveToVibration>
	private final VibrationSystem.Listener vibrationListener = new VibrationSystem.Listener(this);
	private final VibrationSystem.User vibrationUser = new VibrationUser(this.getBlockPos());
	private VibrationSystem.Data vibrationData = new VibrationSystem.Data();
	</#if>

	<#if data.renderType() == 4>
		<#list data.animations as animation>
		public final AnimationState animationState${animation?index} = new AnimationState();
		</#list>
	</#if>

	public ${name}BlockEntity(BlockPos position, BlockState state) {
		super(${JavaModName}BlockEntities.${REGISTRYNAME}, position, state);
	}

	<#if !data.inventoryDropWhenDestroyed>
	@Override public void preRemoveSideEffects(BlockPos blockpos, BlockState blockstate) {
	}
	</#if>

	@Override public void loadAdditional(ValueInput valueInput) {
		super.loadAdditional(valueInput);

		if (!this.tryLoadLootTable(valueInput))
			this.stacks = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);

		ContainerHelper.loadAllItems(valueInput, this.stacks);

		<#if data.sensitiveToVibration>
		this.vibrationData = valueInput.read("listener", VibrationSystem.Data.CODEC).orElseGet(VibrationSystem.Data::new);
		</#if>
	}

	@Override public void saveAdditional(ValueOutput valueOutput) {
		super.saveAdditional(valueOutput);

		if (!this.trySaveLootTable(valueOutput))
			ContainerHelper.saveAllItems(valueOutput, this.stacks);

		<#if data.sensitiveToVibration>
		valueOutput.store("listener", VibrationSystem.Data.CODEC, this.vibrationData);
		</#if>
	}

	@Override public ClientboundBlockEntityDataPacket getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override public CompoundTag getUpdateTag(HolderLookup.Provider lookupProvider) {
		return this.saveWithFullMetadata(lookupProvider);
	}

	@Override public int getContainerSize() {
		return stacks.size();
	}

	@Override public boolean isEmpty() {
		for (ItemStack itemstack : this.stacks)
			if (!itemstack.isEmpty())
				return false;
		return true;
	}

	@Override public Component getDefaultName() {
		return Component.literal("${registryname}");
	}

	<#if data.inventoryStackSize != 99>
	@Override public int getMaxStackSize() {
		return ${data.inventoryStackSize};
	}
	</#if>

	@Override public AbstractContainerMenu createMenu(int id, Inventory inventory) {
		<#if !data.guiBoundTo?has_content>
		return ChestMenu.threeRows(id, inventory);
		<#else>
		return new ${data.guiBoundTo}Menu(id, inventory, this, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(this.worldPosition));
		</#if>
	}

	@Override public Component getDisplayName() {
		return Component.literal("${data.name}");
	}

	@Override protected NonNullList<ItemStack> getItems() {
		return this.stacks;
	}

	@Override protected void setItems(NonNullList<ItemStack> stacks) {
		this.stacks = stacks;
	}

	@Override public boolean canPlaceItem(int index, ItemStack stack) {
		<#list data.inventoryOutSlotIDs as id>
		if (index == ${id})
			return false;
		</#list>
		return true;
	}

	<#-- START: WorldlyContainer -->
	@Override public int[] getSlotsForFace(Direction side) {
		return IntStream.range(0, this.getContainerSize()).toArray();
	}

	@Override public boolean canPlaceItemThroughFace(int index, ItemStack itemstack, @Nullable Direction direction) {
		return this.canPlaceItem(index, itemstack)
		<#if hasProcedure(data.inventoryAutomationPlaceCondition)>&&
			<@procedureCode data.inventoryAutomationPlaceCondition, {
				"index": "index",
				"itemstack": "itemstack",
				"direction": "direction"
			}, false/>
		</#if>;
	}

	@Override public boolean canTakeItemThroughFace(int index, ItemStack itemstack, Direction direction) {
		<#list data.inventoryInSlotIDs as id>
		if (index == ${id})
			return false;
		</#list>
		<#if hasProcedure(data.inventoryAutomationTakeCondition)>
			return <@procedureCode data.inventoryAutomationTakeCondition, {
				"index": "index",
				"itemstack": "itemstack",
				"direction": "direction"
			}, false/>;
		<#else>
			return true;
		</#if>
	}
	<#-- END: WorldlyContainer -->

	<#if data.sensitiveToVibration>
	@Override public VibrationSystem.Data getVibrationData() {
		return this.vibrationData;
	}

	@Override public VibrationSystem.User getVibrationUser() {
		return this.vibrationUser;
	}

	@Override public VibrationSystem.Listener getListener() {
		return this.vibrationListener;
	}

	private class VibrationUser implements VibrationSystem.User {

		private final int x;
		private final int y;
		private final int z;
		private final PositionSource positionSource;

		public VibrationUser(BlockPos blockPos) {
			this.x = blockPos.getX();
			this.y = blockPos.getY();
			this.z = blockPos.getZ();
			this.positionSource = new BlockPositionSource(blockPos);
		}

		@Override public PositionSource getPositionSource() {
			return this.positionSource;
		}

		<#if data.vibrationalEvents?has_content>
		@Override public TagKey<GameEvent> getListenableEvents() {
			return TagKey.create(Registries.GAME_EVENT, ResourceLocation.withDefaultNamespace("${registryname}_can_listen"));
		}
		</#if>

		@Override public int getListenerRadius() {
			<#if hasProcedure(data.vibrationSensitivityRadius)>
				Level world = ${name}BlockEntity.this.getLevel();
				BlockState blockstate = ${name}BlockEntity.this.getBlockState();
				return (int) <@procedureOBJToNumberCode data.vibrationSensitivityRadius/>;
			<#else>
				return ${data.vibrationSensitivityRadius.getFixedValue()};
			</#if>
		}

		@Override public boolean canReceiveVibration(ServerLevel world, BlockPos vibrationPos, Holder<GameEvent> holder, GameEvent.Context context) {
			<#if hasProcedure(data.canReceiveVibrationCondition)>
				return <@procedureCode data.canReceiveVibrationCondition {
					"x": "x",
					"y": "y",
					"z": "z",
					"vibrationX": "vibrationPos.getX()",
					"vibrationY": "vibrationPos.getY()",
					"vibrationZ": "vibrationPos.getZ()",
					"world": "world",
					"entity": "context.sourceEntity()",
					"blockstate": "${name}BlockEntity.this.getBlockState()"
				}/>
			<#else>
				return true;
			</#if>
		}

		@Override public void onReceiveVibration(ServerLevel world, BlockPos vibrationPos, Holder<GameEvent> holder, Entity entity, Entity projectileShooter, float distance) {
			<#if hasProcedure(data.onReceivedVibration)>
				<@procedureCode data.onReceivedVibration {
					"x": "x",
					"y": "y",
					"z": "z",
					"vibrationX": "vibrationPos.getX()",
					"vibrationY": "vibrationPos.getY()",
					"vibrationZ": "vibrationPos.getZ()",
					"world": "world",
					"blockstate": "${name}BlockEntity.this.getBlockState()",
					"entity": "entity",
					"sourceentity": "projectileShooter"
				}/>
			</#if>
		}

		@Override public void onDataChanged() {
			${name}BlockEntity.this.setChanged();
		}

		@Override public boolean requiresAdjacentChunksToBeTicking() {
			return true;
		}
	}
	</#if>
}
</#compress>
<#-- @formatter:on -->